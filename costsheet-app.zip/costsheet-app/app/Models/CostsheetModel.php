<?php namespace App\Models;

use CodeIgniter\Model;

class CostsheetModel extends Model
{
    protected $table = 'costsheets';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'customer_name','mobile_number','flat','type','area','rate','carpet_area',
        'agreement_cost','mseb','society_formation','club_house_charges','total_amount_paid',
        'stamp_duty','maintenance','registration','gst','total_cost'
    ];
}
