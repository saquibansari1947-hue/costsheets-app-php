<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'CostsheetController::form');
$routes->post('save', 'CostsheetController::save');
$routes->get('pdf/(:num)', 'CostsheetController::pdf/$1');

