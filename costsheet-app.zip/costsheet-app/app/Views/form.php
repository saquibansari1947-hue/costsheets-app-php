<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Costsheet Form</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style> body{padding:20px;} .required{color:red;} </style>
</head>
<body>
<div class="container">
  <div class="card mx-auto" style="max-width:900px;">
    <div class="card-body">
      <h4 class="card-title text-center">Costsheet - Fill details</h4>
      <?php if(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
      <?php endif; ?>
      <form method="post" action="<?= site_url('save') ?>">
        <?= csrf_field() ?>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label>Customer Name</label>
            <input name="customer_name" required class="form-control" />
          </div>
          <div class="form-group col-md-3">
            <label>Mobile Number</label>
            <input name="mobile_number" class="form-control" />
          </div>
          <div class="form-group col-md-3">
            <label>Flat</label>
            <input name="flat" class="form-control" />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group col-md-3">
            <label>Type</label>
            <select name="type" class="form-control">
              <option>1 BHK</option>
              <option>2 BHK</option>
              <option>3 BHK</option>
            </select>
          </div>
          <div class="form-group col-md-3">
            <label>Area (sqft)</label>
            <input name="area" required type="number" step="0.01" class="form-control" />
          </div>
          <div class="form-group col-md-3">
            <label>Rate (per sqft)</label>
            <input name="rate" required type="number" step="0.01" class="form-control" />
          </div>
          <div class="form-group col-md-3">
            <label>Carpet Area</label>
            <input name="carpet_area" type="number" step="0.01" class="form-control" />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group col-md-3">
            <label>MSEB</label>
            <input name="mseb" type="number" step="0.01" class="form-control" value="0" />
          </div>
          <div class="form-group col-md-3">
            <label>Society Formation</label>
            <input name="society_formation" type="number" step="0.01" class="form-control" value="0" />
          </div>
          <div class="form-group col-md-3">
            <label>Club House Charges</label>
            <input name="club_house_charges" type="number" step="0.01" class="form-control" value="0" />
          </div>
          <div class="form-group col-md-3">
            <label>Stamp Duty</label>
            <input name="stamp_duty" type="number" step="0.01" class="form-control" value="0" />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group col-md-4">
            <label>Maintenance</label>
            <input name="maintenance" type="number" step="0.01" class="form-control" value="0" />
          </div>
          <div class="form-group col-md-4">
            <label>Registration</label>
            <input name="registration" type="number" step="0.01" class="form-control" value="0" />
          </div>
        </div>

        <button class="btn btn-primary" type="submit">Save & Generate PDF</button>
      </form>
    </div>
  </div>
</div>
</body>
</html>