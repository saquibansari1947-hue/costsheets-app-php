<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Costsheet PDF</title>
<style>
  body{ font-family: Arial, sans-serif; font-size:12px; color:#222; }
  .header { text-align:center; padding:10px 0; }
  .top-info td { padding:4px 8px; }
  .titlebar { background:#333; color:#fff; padding:8px; text-align:center; font-weight:bold; margin-bottom:8px; }
  .table { width:100%; border-collapse: collapse; }
  .table td, .table th { border:1px solid #bbb; padding:8px; }
  .type-header { background:#c62828; color:#fff; text-align:center; font-weight:bold;}
  .muted-row { background:#f5c6c6; }
  .highlight { background:#e57373; color:#fff; font-weight:bold; text-align:center; }
  .right { text-align:right; }
</style>
</head>
<body>

<div class="header">
  <h2>GANGA FERNHILL PHASE — UNDRI</h2>
</div>

<table class="top-info">
  <tr>
    <td><strong>Customer Name:</strong> <?= esc($data['customer_name']) ?></td>
    <td><strong>Mobile Number:</strong> <?= esc($data['mobile_number']) ?></td>
    <td><strong>Flat:</strong> <?= esc($data['flat']) ?></td>
  </tr>
</table>

<div class="titlebar">COSTSHEET DETAILS & CALCULATIONS</div>

<table class="table">
  <tr>
    <th class="type-header">Type</th>
    <th class="type-header"> <?= esc($data['type']) ?> </th>
  </tr>

  <tr class="muted-row"><td>Area</td><td class="right"><?= number_format($data['area'],2) ?></td></tr>
  <tr class="muted-row"><td>Rate</td><td class="right"><?= number_format($data['rate'],2) ?></td></tr>
  <tr class="muted-row"><td>Carpet Area</td><td class="right"><?= number_format($data['carpet_area'],2) ?></td></tr>

  <tr><td>Agr. Cost</td><td class="right"><?= number_format($data['agreement_cost'],2) ?></td></tr>
  <tr><td>MSEB</td><td class="right"><?= number_format($data['mseb'],2) ?></td></tr>
  <tr><td>Society Formation</td><td class="right"><?= number_format($data['society_formation'],2) ?></td></tr>
  <tr><td>Club House Charges</td><td class="right"><?= number_format($data['club_house_charges'],2) ?></td></tr>

  <tr class="highlight"><td>Total Amount Paid to Developer</td><td class="right"><?= number_format($data['total_amount_paid'],2) ?></td></tr>

  <tr><td>Stamp-Duty</td><td class="right"><?= number_format($data['stamp_duty'],2) ?></td></tr>
  <tr><td>Maintenance</td><td class="right"><?= number_format($data['maintenance'],2) ?></td></tr>
  <tr><td>Registration</td><td class="right"><?= number_format($data['registration'],2) ?></td></tr>

  <tr><td>GST</td><td class="right"><?= number_format($data['gst'],2) ?></td></tr>

  <tr class="highlight"><td>Total cost</td><td class="right"><?= number_format($data['total_cost'],2) ?></td></tr>
</table>

</body>
</html>
<!-- this is for pdf viewer -->
 <!-- now i run the on the local server this web page. thank you and test it again  -->
  <!-- it showing data because i already test it -->
   <!-- you can see it's work successfuly thank you for giving me 
    this amazing mini project it is helping me for exploring
    something new challenge. i also hope you will take 
    good decision for me. thank you mam/sir! -->