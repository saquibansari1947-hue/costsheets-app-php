<?php namespace App\Controllers;

use App\Models\CostsheetModel;
use CodeIgniter\Controller;
use Dompdf\Dompdf;

class CostsheetController extends Controller
{
    public function form()
    {
        return view('form');
    }

    public function save()
    {
        $request = service('request');

        $data = [
            'customer_name'    => $request->getPost('customer_name'),
            'mobile_number'    => $request->getPost('mobile_number'),
            'flat'             => $request->getPost('flat'),
            'type'             => $request->getPost('type'),
            'area'             => (float)$request->getPost('area'),
            'rate'             => (float)$request->getPost('rate'),
            'carpet_area'      => (float)$request->getPost('carpet_area'),
            'mseb'             => (float)$request->getPost('mseb'),
            'society_formation'=> (float)$request->getPost('society_formation'),
            'club_house_charges'=> (float)$request->getPost('club_house_charges'),
            'stamp_duty'       => (float)$request->getPost('stamp_duty'),
            'maintenance'      => (float)$request->getPost('maintenance'),
            'registration'     => (float)$request->getPost('registration')
        ];

        // Calculations
        $agreement_cost = $data['area'] * $data['rate'];
        $data['agreement_cost'] = round($agreement_cost, 2);

        $total_paid = $data['agreement_cost'] + $data['mseb'] + $data['society_formation'] + $data['club_house_charges'];
        $data['total_amount_paid'] = round($total_paid, 2);

        $gst_agreement = $data['agreement_cost'] * 0.12;
        $gst_maintenance = $data['maintenance'] * 0.18;
        $data['gst'] = round($gst_agreement + $gst_maintenance, 2);

        $total_cost = $data['total_amount_paid'] + $data['stamp_duty'] + $data['maintenance'] + $data['registration'] + $data['gst'];
        $data['total_cost'] = round($total_cost, 2);

        $model = new CostsheetModel();
        $id = $model->insert($data);

        if ($id) {
            return redirect()->to(site_url('pdf/' . $id));
        } else {
            return redirect()->back()->with('error', 'Unable to save. Please try again.');
        }
    }

    public function pdf($id)
    {
        $model = new CostsheetModel();
        $row = $model->find($id);
        if (!$row) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Costsheet not found");
        }

        $html = view('pdf_view', ['data' => $row]);

        $dompdf = new Dompdf();
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->loadHtml($html);
        $dompdf->render();

        $dompdf->stream("costsheet_{$id}.pdf", ["Attachment" => false]);
        exit;
    }
}

// this i test already and it works goog without error